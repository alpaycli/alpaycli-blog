//
//  VideoEditorApp.swift
//  VideoEditor
//
//  Created by Example Developer on 14.08.26.
//

import SwiftUI

@main
struct VideoEditorApp: App {
    var body: some Scene {
        WindowGroup {
            TranscriptDemoView()
        }
    }
}
