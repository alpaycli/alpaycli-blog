//
//  SubtitleGrouper.swift
//  VideoEditor
//

import AVFoundation

/// Applies the same character-count grouping used by the complete SpeechLess app.
struct SubtitleGrouper {
    private let maximumCharacterCount = 40

    func apply(to words: [TranscriptWord]) -> [SubtitleGroup] {
        let timedWords = words.filter { $0.audioTimeRange != nil }
        guard !timedWords.isEmpty else { return [] }

        var groups: [SubtitleGroup] = []
        var currentWords: [TranscriptWord] = []
        var currentCharacterCount = 0

        for word in timedWords {
            let separatorCount = currentWords.isEmpty ? 0 : 1
            let proposedCount = currentCharacterCount + separatorCount + word.word.characters.count

            if currentWords.isEmpty || proposedCount < maximumCharacterCount {
                currentWords.append(word)
                currentCharacterCount = proposedCount
            } else {
                groups.append(makeGroup(from: currentWords, endTime: word.audioTimeRange?.start))
                currentWords = [word]
                currentCharacterCount = word.word.characters.count
            }
        }

        if let finalEndTime = currentWords.last?.audioTimeRange?.end {
            groups.append(makeGroup(from: currentWords, endTime: finalEndTime))
        }

        return groups
    }

    private func makeGroup(from words: [TranscriptWord], endTime: CMTime?) -> SubtitleGroup {
        let startTime = words.first?.audioTimeRange?.start ?? .zero
        let endTime = endTime ?? words.last?.audioTimeRange?.end ?? startTime
        let text = AttributedString(
            words
                .map { String($0.word.characters) }
                .joined(separator: " ")
        )

        return SubtitleGroup(
            text: text,
            words: words,
            startTime: startTime,
            endTime: endTime
        )
    }
}
