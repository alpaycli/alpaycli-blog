//
//  TranscriptDemoView.swift
//  BlogPostDemos
//

import AVKit
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

struct TranscriptDemoView: View {
    @State private var model = TranscriptDemoViewModel()
    @State private var isFileImporterPresented = false
    @State private var isPhotoPickerPresented = false
    @State private var photoPickerItem: PhotosPickerItem?

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                if let player = model.player {
                    VideoPlayer(player: player) {
                        SubtitleOverlayView(
                            group: model.currentSubtitleGroup,
                            currentWord: model.currentSubtitleWord,
                            showMethod: model.subtitleShowMethod
                        )
                    }
                        .aspectRatio(16 / 9, contentMode: .fit)
                        .clipShape(.rect(cornerRadius: 12))

                    SubtitleShowMethodPicker(selection: $model.subtitleShowMethod)

                    TranscriptContainerView(
                        transcript: model.transcript,
                        words: model.transcriptWords,
                        playbackTime: model.playbackTime,
                        onSelectWord: model.seek
                    )
                } else {
                    contentUnavailableView
                }
            }
            .padding()
        }
        .safeAreaInset(edge: .bottom) {
            if model.player != nil {
                videoImporterView
            }
        }
        .fileImporter(
            isPresented: $isFileImporterPresented,
            allowedContentTypes: [.movie],
            allowsMultipleSelection: false,
            onCompletion: handleFileImport
        )
        .photosPicker(
            isPresented: $isPhotoPickerPresented,
            selection: $photoPickerItem,
            matching: .videos
        )
        .onChange(of: photoPickerItem, handlePhotoSelection)
        .onDisappear(perform: model.stopPlayback)
    }

    private func handleFileImport(_ result: Result<[URL], any Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            Task {
                await model.importVideo(from: url)
            }
        case .failure(let error):
            model.reportFileImportFailure(error)
        }
    }

    private func handlePhotoSelection(_ oldItem: PhotosPickerItem?, _ newItem: PhotosPickerItem?) {
        guard let newItem else { return }

        Task {
            await model.importVideo(from: newItem)
            photoPickerItem = nil
        }
    }
}

extension TranscriptDemoView {
    private var contentUnavailableView: some View {
        ContentUnavailableView {
            Label("Import a Video", systemImage: "video.badge.plus")
        } description: {
            Text("Choose a video from Files or your Photo Library to create a word-timed transcript.")
        } actions: {
            VideoImportMenu(
                isFileImporterPresented: $isFileImporterPresented,
                isPhotoPickerPresented: $isPhotoPickerPresented,
                isDisabled: model.isProcessing
            )
        }
        .containerRelativeFrame(.vertical) { height, _ in
            height * 0.65
        }
    }
    
    private var videoImporterView: some View {
        VideoImportMenu(
            isFileImporterPresented: $isFileImporterPresented,
            isPhotoPickerPresented: $isPhotoPickerPresented,
            isDisabled: model.isProcessing
        )
        .padding()
    }
}

#Preview {
    TranscriptDemoView()
}
