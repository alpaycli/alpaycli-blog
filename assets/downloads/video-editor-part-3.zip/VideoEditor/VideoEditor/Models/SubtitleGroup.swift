//
//  SubtitleGroup.swift
//  VideoEditor
//

import AVFoundation

/// A short group of timed words displayed together over the video.
struct SubtitleGroup: Identifiable {
    let id = UUID()
    let text: AttributedString
    let words: [TranscriptWord]
    let startTime: CMTime
    let endTime: CMTime
}
