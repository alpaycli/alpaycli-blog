//
//  SubtitleShowMethod.swift
//  VideoEditor
//

import SwiftUI

enum SubtitleShowMethod: String, CaseIterable, Identifiable {
    case oneWord
    case wholeSentence
    case wholeSentenceWithHighlightedWord

    var id: Self { self }

    var description: LocalizedStringResource {
        switch self {
        case .oneWord:
            "One Word"
        case .wholeSentence:
            "Whole Sentence"
        case .wholeSentenceWithHighlightedWord:
            "Whole Sentence with Word Highlighting"
        }
    }
}
