//
//  SubtitleShowMethodPicker.swift
//  VideoEditor
//

import SwiftUI

struct SubtitleShowMethodPicker: View {
    @Binding var selection: SubtitleShowMethod

    var body: some View {
        Picker("Subtitle Display", selection: $selection) {
            ForEach(SubtitleShowMethod.allCases) { method in
                Text(method.description)
                    .tag(method)
            }
        }
        .pickerStyle(.segmented)
    }
}
