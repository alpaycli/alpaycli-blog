//
//  SubtitleLayout.swift
//  VideoEditor
//

import SwiftUI

/// Wraps subtitle words into centered rows.
struct SubtitleLayout: Layout {
    var alignment: Alignment = .center
    var spacing: CGFloat = 4

    func sizeThatFits(
        proposal: ProposedViewSize,
        subviews: Subviews,
        cache: inout ()
    ) -> CGSize {
        let maximumWidth = proposal.width ?? .infinity
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)

            if x > 0, x + size.width > maximumWidth {
                x = 0
                y += rowHeight
                rowHeight = 0
            }

            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }

        return CGSize(width: maximumWidth, height: y + rowHeight)
    }

    func placeSubviews(
        in bounds: CGRect,
        proposal: ProposedViewSize,
        subviews: Subviews,
        cache: inout ()
    ) {
        let rows = rows(for: subviews, maximumWidth: bounds.width)
        var y = bounds.minY

        for row in rows {
            let rowWidth = row.reduce(0) {
                $0 + $1.sizeThatFits(.unspecified).width
            } + CGFloat(max(row.count - 1, 0)) * spacing

            var x = startingX(for: rowWidth, in: bounds)
            var rowHeight: CGFloat = 0

            for subview in row {
                let size = subview.sizeThatFits(.unspecified)
                subview.place(
                    at: CGPoint(x: x, y: y),
                    proposal: ProposedViewSize(size)
                )
                x += size.width + spacing
                rowHeight = max(rowHeight, size.height)
            }

            y += rowHeight
        }
    }

    private func rows(for subviews: Subviews, maximumWidth: CGFloat) -> [[LayoutSubview]] {
        var rows: [[LayoutSubview]] = []
        var currentRow: [LayoutSubview] = []
        var currentWidth: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)

            if !currentRow.isEmpty, currentWidth + size.width > maximumWidth {
                rows.append(currentRow)
                currentRow = []
                currentWidth = 0
            }

            currentRow.append(subview)
            currentWidth += size.width + spacing
        }

        if !currentRow.isEmpty {
            rows.append(currentRow)
        }

        return rows
    }

    private func startingX(for rowWidth: CGFloat, in bounds: CGRect) -> CGFloat {
        switch alignment {
        case .leading:
            bounds.minX
        case .trailing:
            bounds.maxX - rowWidth
        default:
            bounds.minX + (bounds.width - rowWidth) / 2
        }
    }
}
