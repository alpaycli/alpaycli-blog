//
//  SubtitleOverlayView.swift
//  VideoEditor
//

import SwiftUI

struct SubtitleOverlayView: View {
    let group: SubtitleGroup?
    let currentWord: TranscriptWord?
    let showMethod: SubtitleShowMethod

    var body: some View {
        Group {
            if let group {
                switch showMethod {
                case .oneWord:
                    if let currentWord {
                        Text(String(currentWord.word.characters))
                    }
                case .wholeSentence:
                    Text(group.text)
                        .multilineTextAlignment(.center)
                case .wholeSentenceWithHighlightedWord:
                    SubtitleLayout(alignment: .center) {
                        ForEach(group.words) { word in
                            Text(String(word.word.characters))
                                .foregroundStyle(
                                    word.id == currentWord?.id ? .yellow : .white.opacity(0.95)
                                )
                        }
                    }
                }
            }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 24)
        .padding(.bottom, 24)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
        .font(.headline.weight(.semibold))
        .fontDesign(.rounded)
        .shadow(color: .black.opacity(0.85), radius: 6)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
