//
//  AttributedString+TranscriptWords.swift
//  VideoEditor
//

import Foundation

extension AttributedString {
    /// Splits the transcript without discarding each word's Speech attributes.
    func transcriptWords() -> [TranscriptWord] {
        characters
            .split { character in
                character.isWhitespace || character.isNewline
            }
            .map { characterRange in
                TranscriptWord(word: self[characterRange.startIndex..<characterRange.endIndex])
            }
    }
}
