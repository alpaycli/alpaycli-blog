//
//  DynamicTranscriptTextView.swift
//  BlogPostDemos
//

import AVFoundation
import SwiftUI

/// Renders each timed word as a button that seeks the video when selected.
///
/// Used by ``TranscriptContainerView``.
///
struct DynamicTranscriptTextView: View {
    let words: [TranscriptWord]
    let playbackTime: TimeInterval
    let onSelectWord: (CMTime) -> Void

    var body: some View {
        TranscriptLayout {
            ForEach(words) { word in
                let isHighlighted = isHighlighted(word)

                Button {
                    guard let startTime = word.audioTimeRange?.start else { return }
                    onSelectWord(startTime)
                } label: {
                    Text(String(word.word.characters))
                        .font(.body)
                        .lineLimit(1)
                        .foregroundStyle(isHighlighted ? .primary : .secondary)
                        .underline(isHighlighted)
                }
                .buttonStyle(TranscriptWordButtonStyle())
                .background(
                    isHighlighted ? Color.mint.opacity(0.35) : .clear,
                    in: .rect(cornerRadius: 8)
                )
                .disabled(word.audioTimeRange == nil)
                .accessibilityLabel(String(word.word.characters))
                .accessibilityHint("Seeks the video to this word")
                .accessibilityValue(isHighlighted ? "Currently speaking" : "")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func isHighlighted(_ word: TranscriptWord) -> Bool {
        guard let timeRange = word.audioTimeRange else { return false }

        let start = timeRange.start.seconds
        let end = timeRange.end.seconds
        return start <= playbackTime && playbackTime < end
    }
}
