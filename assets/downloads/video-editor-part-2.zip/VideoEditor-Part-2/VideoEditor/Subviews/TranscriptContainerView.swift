//
//  TranscriptContainerView.swift
//  BlogPostDemos
//

import AVFoundation
import SwiftUI

struct TranscriptContainerView: View {
    let transcript: AttributedString?
    let words: [TranscriptWord]
    let playbackTime: TimeInterval
    let onSelectWord: (CMTime) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Transcript")
                .font(.headline)

            if transcript != nil {
                DynamicTranscriptTextView(
                    words: words,
                    playbackTime: playbackTime,
                    onSelectWord: onSelectWord
                )
            } else {
                Text("The transcript will appear here when transcription finishes.")
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 160, alignment: .topLeading)
        .background(.quaternary, in: .rect(cornerRadius: 12))
    }
}
