//
//  TranscriptWordButtonStyle.swift
//  VideoEditor
//

import SwiftUI

struct TranscriptWordButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background {
                if configuration.isPressed {
                    RoundedRectangle(cornerRadius: 8)
                        .inset(by: -4)
                        .fill(.thinMaterial)
                }
            }
            .sensoryFeedback(.selection, trigger: configuration.isPressed)
    }
}
