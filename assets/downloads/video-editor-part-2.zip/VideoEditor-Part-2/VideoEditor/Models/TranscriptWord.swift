//
//  TranscriptWord.swift
//  VideoEditor
//

import AVFoundation
import Speech

/// A single displayed transcript word with the timing attached by Speech.
struct TranscriptWord: Identifiable {
    let id = UUID()
    let word: AttributedSubstring

    var audioTimeRange: CMTimeRange? {
        word.audioTimeRange
    }
}
