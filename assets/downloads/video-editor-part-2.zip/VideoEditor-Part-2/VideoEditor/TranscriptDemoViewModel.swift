//
//  TranscriptDemoViewModel.swift
//  BlogPostDemos
//

import AVFoundation
import Observation
import PhotosUI
import SwiftUI

/// Coordinates importing, audio extraction, transcription, and video playback.
///
/// The view owns this model, while the model exposes only UI-facing state. Media
/// processing details stay in the focused helper types below it.
@MainActor
@Observable
final class TranscriptDemoViewModel {
    private(set) var player: AVPlayer?
    /// Speech's attributed result, including an `audioTimeRange` on each word.
    private(set) var transcript: AttributedString?
    private(set) var transcriptWords: [TranscriptWord] = []
    private(set) var playbackTime: TimeInterval = 0
    private(set) var state = TranscriptState.empty

    @ObservationIgnored private let audioExtractor = VideoAudioExtractor()
    @ObservationIgnored private let transcriber: Transcribable = Transcriber()
    @ObservationIgnored private let videoStore = ImportedVideoStore()
    @ObservationIgnored private var timeObserver: Any?

    init() {
        AVPlayer.isObservationEnabled = true
    }

    var isProcessing: Bool {
        state.isProcessing
    }

    func importVideo(from fileURL: URL) async {
        state = .importing

        // File importer URLs require explicit access. Copy the video while access
        // is active, then release the external file immediately afterward.
        guard fileURL.startAccessingSecurityScopedResource() else {
            state = .failed("The selected file could not be accessed.")
            return
        }

        defer {
            fileURL.stopAccessingSecurityScopedResource()
        }

        do {
            let localURL = try await videoStore.copyVideo(from: fileURL)
            try await processVideo(at: localURL)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func importVideo(from item: PhotosPickerItem) async {
        state = .importing

        do {
            guard let video = try await item.loadTransferable(type: TransferableVideo.self) else {
                throw TranscriptError.photoImportFailed
            }

            try await processVideo(at: video.url)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func reportFileImportFailure(_ error: any Error) {
        state = .failed(error.localizedDescription)
    }

    func stopPlayback() {
        player?.pause()
    }

    func seek(to time: CMTime) {
        player?.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    private func processVideo(at videoURL: URL) async throws {
        // Playback can be prepared immediately; transcription does not need to
        // finish before the user can inspect the selected video.
        preparePlayer(for: videoURL)
        transcript = nil
        transcriptWords = []
        playbackTime = 0
        state = .extractingAudio

        let audioURL = try await audioExtractor.extractAudio(from: videoURL)
        defer {
            // The extracted track is an intermediate input, not user data.
            try? FileManager.default.removeItem(at: audioURL)
        }

        state = .transcribing
        let transcript = try await transcriber.transcribe(audioAt: audioURL)
        self.transcript = transcript
        transcriptWords = transcript.transcriptWords()
        state = .ready
    }

    private func preparePlayer(for videoURL: URL) {
        // An observer belongs to the player that created it, so remove the old
        // token before replacing the player with one for a newly imported video.
        removeTimeObserver()
        player?.pause()

        let player = AVPlayer(url: videoURL)
        self.player = player

        // Native VideoPlayer owns play, pause, and seeking controls. This observer
        // mirrors its clock into observable state so the transcript follows them.
        let interval = CMTime(seconds: 0.05, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in
                self?.playbackTime = time.seconds
            }
        }
    }

    private func removeTimeObserver() {
        guard let player, let timeObserver else { return }
        player.removeTimeObserver(timeObserver)
        self.timeObserver = nil
    }
}
