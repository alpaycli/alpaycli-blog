//
//  VideoAudioExtractor.swift
//  BlogPostDemos
//

import AVFoundation

/// Exports only a video's audio track to a temporary M4A file.
///
/// The Speech analyzer consumes this audio-only file; the original video remains
/// unchanged and is used separately by AVPlayer.
struct VideoAudioExtractor {
    /// Returns a temporary audio URL that the caller owns and should delete.
    func extractAudio(from videoURL: URL) async throws -> URL {
        let asset = AVURLAsset(url: videoURL)
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)

        guard !audioTracks.isEmpty else {
            throw TranscriptError.noAudioTrack
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appending(path: UUID().uuidString)
            .appendingPathExtension("m4a")

        guard let exporter = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetAppleM4A
        ) else {
            throw TranscriptError.audioExportUnavailable
        }

        try await exporter.export(to: outputURL, as: .m4a)
        return outputURL
    }
}
