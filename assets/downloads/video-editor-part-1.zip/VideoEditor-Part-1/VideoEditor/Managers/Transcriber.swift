//
//  Transcriber.swift
//  BlogPostDemos
//

import Speech

protocol Transcribable {
    func transcribe(audioAt url: URL) async throws -> AttributedString
}

/// Transcribes an audio file on device and preserves word-level timestamps.
final class Transcriber: Transcribable {
    private let locale = Locale(identifier: "en-US")

    /// Produces attributed text whose words retain their audio time ranges.
    func transcribe(audioAt url: URL) async throws -> AttributedString {
        guard SpeechTranscriber.isAvailable else {
            throw TranscriptError.notAvailable
        }

        let transcriber = SpeechTranscriber(
            locale: locale,
            transcriptionOptions: [],
            reportingOptions: [],
            // Without this option, the returned text has no word timing data.
            attributeOptions: [.audioTimeRange]
        )

        let analyzer = SpeechAnalyzer(modules: [transcriber])
        let audioFile = try AVAudioFile(forReading: url)

        // `analyzeSequence` feeds the complete file to SpeechAnalyzer. Finalizing
        // through its last sample tells the analyzer that no more audio is coming.
        if let lastSample = try await analyzer.analyzeSequence(from: audioFile) {
            try await analyzer.finalizeAndFinish(through: lastSample)
        } else {
            await analyzer.cancelAndFinishNow()
        }

        var transcription = AttributedString()

        for try await result in transcriber.results where result.isFinal {
            transcription.append(result.text)
        }

        guard !transcription.characters.isEmpty else {
            throw TranscriptError.emptyTranscript
        }

        return transcription
    }
}
