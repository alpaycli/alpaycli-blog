//
//  ImportedVideoStore.swift
//  BlogPostDemos
//

import Foundation

/// Copies a Files selection into a location the app can continue reading.
///
/// URLs returned by `fileImporter` are security-scoped and may stop being
/// available when that access ends. Processing a private temporary copy avoids
/// keeping the external document open throughout playback and transcription.
actor ImportedVideoStore {
    /// Creates and returns a uniquely named temporary copy of a selected video.
    func copyVideo(from sourceURL: URL) throws -> URL {
        let destinationURL = FileManager.default.temporaryDirectory
            .appending(path: UUID().uuidString)
            .appendingPathExtension(sourceURL.pathExtension)

        try FileManager.default.copyItem(at: sourceURL, to: destinationURL)
        return destinationURL
    }
}
