//
//  TransferableVideo.swift
//  BlogPostDemos
//

import CoreTransferable
import Foundation
import UniformTypeIdentifiers

/// A durable local copy of a video selected through `PhotosPicker`.
///
/// The URL supplied to a transfer closure is temporary. Copying the file before
/// the closure returns ensures AVPlayer and the audio extractor can use it later.
struct TransferableVideo: Transferable {
    let url: URL

    nonisolated static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .movie) { receivedVideo in
            let sourceURL = receivedVideo.file
            let destinationURL = FileManager.default.temporaryDirectory
                .appending(path: UUID().uuidString)
                .appendingPathExtension(sourceURL.pathExtension)

            try FileManager.default.copyItem(at: sourceURL, to: destinationURL)
            return TransferableVideo(url: destinationURL)
        }
    }
}
