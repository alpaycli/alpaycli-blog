//
//  TranscriptState.swift
//  BlogPostDemos
//

/// The user-visible stages of the import and transcription pipeline.
enum TranscriptState {
    case empty
    case importing
    case extractingAudio
    case transcribing
    case ready
    case failed(String)

    var isProcessing: Bool {
        switch self {
        case .importing, .extractingAudio, .transcribing:
            true
        case .empty, .ready, .failed:
            false
        }
    }

    var statusText: String {
        switch self {
        case .empty:
            "Choose a video to begin."
        case .importing:
            "Importing video..."
        case .extractingAudio:
            "Extracting the audio track..."
        case .transcribing:
            "Transcribing audio and creating word timings..."
        case .ready:
            "Transcript ready. Use the video controls to follow each word."
        case .failed(let message):
            message
        }
    }
}
