//
//  TranscriptError.swift
//  BlogPostDemos
//

import Foundation

enum TranscriptError: LocalizedError {
    case photoImportFailed
    case noAudioTrack
    case audioExportUnavailable
    case emptyTranscript
    case notAvailable

    var errorDescription: String? {
        switch self {
        case .photoImportFailed:
            "The selected Photos video could not be imported."
        case .noAudioTrack:
            "The selected video does not contain an audio track."
        case .audioExportUnavailable:
            "The video's audio track could not be extracted."
        case .emptyTranscript:
            "No speech was found in the video's audio track."
        case .notAvailable:
            "Analyzing speech is not available due to your device's hardware capabilities."
        }
    }
}
