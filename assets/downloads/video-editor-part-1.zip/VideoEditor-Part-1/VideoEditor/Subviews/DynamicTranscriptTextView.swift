//
//  DynamicTranscriptTextView.swift
//  BlogPostDemos
//

import Speech
import SwiftUI

/// Renders a timed transcript and emphasizes the word spoken at `playbackTime`.
///
/// Used by ``TranscriptContainerView``.
///
/// `transcript` comes directly from `SpeechTranscriber`. Each word carries an
/// `audioTimeRange` attribute, so no separate word-timing model is needed.
struct DynamicTranscriptTextView: View {
    let transcript: AttributedString
    let playbackTime: TimeInterval

    var body: some View {
        Text(highlightedTranscript)
            .font(.body)
            .multilineTextAlignment(.leading)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityLabel(String(transcript.characters))
    }

    private var highlightedTranscript: AttributedString {
        var result = transcript
        result.foregroundColor = .secondary

        // Query a one-tick interval because Speech exposes timing as ranges and
        // provides a helper for finding the attributed text that intersects one.
        let currentTime = CMTime(seconds: playbackTime, preferredTimescale: 600)
        let instant = CMTimeRange(
            start: currentTime,
            duration: CMTime(value: 1, timescale: 600)
        )

        guard let currentWord = result.rangeOfAudioTimeRangeAttributes(intersecting: instant) else {
            return result
        }

        result[currentWord].foregroundColor = .primary
        result[currentWord].backgroundColor = .mint.opacity(0.35)
        result[currentWord].underlineStyle = .single
        return result
    }
}
