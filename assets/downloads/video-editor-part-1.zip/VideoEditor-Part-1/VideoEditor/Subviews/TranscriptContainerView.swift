//
//  TranscriptContainerView.swift
//  BlogPostDemos
//

import SwiftUI

struct TranscriptContainerView: View {
    let transcript: AttributedString?
    let playbackTime: TimeInterval

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Transcript")
                .font(.headline)

            if let transcript {
                DynamicTranscriptTextView(
                    transcript: transcript,
                    playbackTime: playbackTime
                )
            } else {
                Text("The transcript will appear here when transcription finishes.")
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 160, alignment: .topLeading)
        .background(.quaternary, in: .rect(cornerRadius: 12))
    }
}
