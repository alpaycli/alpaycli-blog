//
//  VideoImportMenu.swift
//  BlogPostDemos
//

import SwiftUI

/// Presents the two supported video sources.
struct VideoImportMenu: View {
    @Binding var isFileImporterPresented: Bool
    @Binding var isPhotoPickerPresented: Bool
    let isDisabled: Bool

    var body: some View {
        Menu("Import Video", systemImage: "video.badge.plus") {
            Button("Photo Library", systemImage: "photo.on.rectangle") {
                isPhotoPickerPresented = true
            }

            Button("Files", systemImage: "folder") {
                isFileImporterPresented = true
            }
        }
        .buttonStyle(.borderedProminent)
        .disabled(isDisabled)
    }
}
